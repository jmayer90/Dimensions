import bmesh
import bpy

from ..anchors import resolve_anchor, set_object_anchor
from ..area_binding import bind_area_face_indices, evaluate_area_binding, evaluate_area_face_indices
from ..collections import create_dimension_object
from ..constants import DEFAULT_OFFSET_DISTANCE
from ..drawing import clear_preview_state, set_preview_state
from ..properties import is_dimension_object
from ..snapping import copy_snap, find_nearest_snap_point, has_view3d_window_region, raycast_from_mouse


class DIMENSIONS_OT_CreateArea(bpy.types.Operator):
    bl_idname = "dimensions.create_area"
    bl_label = "Create Area Dimension"
    bl_description = "Choose source faces, then place the Area label"
    bl_options = {"REGISTER", "UNDO"}

    replace_active: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def invoke(self, context, _event):
        if not has_view3d_window_region(context):
            self.report({"ERROR"}, "Run this operator from a 3D View")
            return {"CANCELLED"}
        if context.mode not in {"OBJECT", "EDIT_MESH"}:
            self.report({"ERROR"}, "Area dimensions work in Object Mode or Mesh Edit Mode")
            return {"CANCELLED"}
        self.target_name = ""
        if self.replace_active:
            active = context.view_layer.objects.active
            if not is_dimension_object(active) or active.dimension_props.annotation_kind != "AREA":
                self.report({"ERROR"}, "Select an Area dimension to remake")
                return {"CANCELLED"}
            self.target_name = active.name

        self.source_object = None
        self.face_indices = []
        self.hover_snap = None
        self.label_snap = None
        self.area_result = None
        self.state = "PICK_FACE"
        if context.mode == "EDIT_MESH" and context.edit_object is not None:
            bm = bmesh.from_edit_mesh(context.edit_object.data)
            bm.faces.ensure_lookup_table()
            selected = [face.index for face in bm.faces if face.select and not face.hide]
            if selected:
                self.source_object = context.edit_object
                self.face_indices = selected
                self.area_result = evaluate_area_face_indices(self.source_object, self.face_indices)
                if self.area_result is not None:
                    self.state = "PLACE_LABEL"
        self._update_preview()
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not has_view3d_window_region(context):
            clear_preview_state()
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            if self.state == "PICK_FACE":
                self.hover_snap = find_nearest_snap_point(
                    context,
                    event.mouse_region_x,
                    event.mouse_region_y,
                    include_guides=False,
                    include_free=False,
                )
            else:
                self.hover_snap = find_nearest_snap_point(
                    context,
                    event.mouse_region_x,
                    event.mouse_region_y,
                    include_free=True,
                    plane_point=self.area_result["center"],
                    plane_normal=self.area_result["normal"],
                )
                self.label_snap = copy_snap(self.hover_snap) if self.hover_snap is not None else None
            self._update_preview()
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            if self.state == "PICK_FACE":
                return self._accept_face(context, event)
            return self._commit(context)
        if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS":
            if self.state == "PICK_FACE" and self.face_indices:
                self.area_result = evaluate_area_face_indices(self.source_object, self.face_indices)
                if self.area_result is not None:
                    self.state = "PLACE_LABEL"
                    self._update_preview()
            elif self.state == "PLACE_LABEL" and self.label_snap is not None:
                return self._commit(context)
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and event.value == "PRESS":
            if self.state == "PLACE_LABEL" and context.mode == "OBJECT":
                self.state = "PICK_FACE"
                self.label_snap = None
                self._update_preview()
                return {"RUNNING_MODAL"}
            clear_preview_state()
            return {"CANCELLED"}
        if event.type == "RIGHTMOUSE" and event.value == "PRESS":
            clear_preview_state()
            return {"CANCELLED"}
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            return {"PASS_THROUGH"}
        return {"RUNNING_MODAL"}

    def _accept_face(self, context, event):
        snap = self.hover_snap
        source = None if snap is None else snap.get("object")
        face_index = -1 if snap is None else snap.get("face_index", -1)
        if source is None or face_index < 0:
            hit = raycast_from_mouse(context, event.mouse_region_x, event.mouse_region_y)
            if hit is not None:
                source = hit.get("object")
                face_index = hit.get("face_index", -1)
        if source is None or source.type != "MESH" or face_index < 0:
            self.report({"WARNING"}, "Point at a base-mesh face")
            return {"RUNNING_MODAL"}
        if source.modifiers and context.mode == "OBJECT":
            self.report({"WARNING"}, "Object Mode Area currently requires an unmodified base mesh")
            return {"RUNNING_MODAL"}
        if self.source_object is not None and source != self.source_object:
            self.report({"WARNING"}, "One Area dimension can bind faces from only one object")
            return {"RUNNING_MODAL"}
        self.source_object = source
        if event.shift:
            if face_index in self.face_indices:
                self.face_indices.remove(face_index)
            else:
                self.face_indices.append(face_index)
            self.area_result = evaluate_area_face_indices(source, self.face_indices)
            self._update_preview()
            return {"RUNNING_MODAL"}
        if face_index not in self.face_indices:
            self.face_indices.append(face_index)
        self.area_result = evaluate_area_face_indices(source, self.face_indices)
        if self.area_result is None:
            self.report({"WARNING"}, "Selected faces have no measurable area")
            return {"RUNNING_MODAL"}
        self.state = "PLACE_LABEL"
        self._update_preview()
        return {"RUNNING_MODAL"}

    def _commit(self, context):
        if self.label_snap is None or self.source_object is None or self.area_result is None:
            return {"RUNNING_MODAL"}
        annotation = bpy.data.objects.get(self.target_name) if self.target_name else None
        if annotation is None:
            annotation = create_dimension_object(context, "AREA Faces")
        props = annotation.dimension_props
        props.annotation_kind = "AREA"
        result = bind_area_face_indices(props, self.source_object, self.face_indices)
        if result is None:
            self.report({"ERROR"}, "Area source became invalid before commit")
            clear_preview_state()
            return {"CANCELLED"}
        props.area_value = result["area"]
        props.area_face_count = result["face_count"]
        set_object_anchor(props.start, self.source_object, result["center"])
        set_object_anchor(props.end, self.source_object, self.label_snap["world_co"])
        annotation.location = self.label_snap["world_co"]
        clear_preview_state()
        if context.mode == "OBJECT":
            for selected in context.selected_objects:
                selected.select_set(False)
            annotation.select_set(True)
            context.view_layer.objects.active = annotation
        self.report({"INFO"}, f"{'Remade' if self.target_name else 'Created'} Area from {len(self.face_indices)} face(s)")
        return {"FINISHED"}

    def _update_preview(self):
        preview = {"state": self.state, "annotation_kind": "AREA"}
        if self.hover_snap is not None:
            preview["hover_screen"] = self.hover_snap["screen_co"]
            preview["hover_type"] = self.hover_snap.get("type", "WORLD")
            preview["hover_label"] = self.hover_snap.get("label", "Point")
        if self.area_result is not None:
            preview["start_world"] = self.area_result["center"]
            preview["end_world"] = (
                self.label_snap["world_co"]
                if self.label_snap is not None
                else self.area_result["center"] + self.area_result["normal"] * DEFAULT_OFFSET_DISTANCE
            )
            preview["area_value"] = self.area_result["area"]
            preview["face_count"] = self.area_result["face_count"]
        set_preview_state(preview)


class DIMENSIONS_OT_MoveAreaLabel(bpy.types.Operator):
    bl_idname = "dimensions.move_area_label"
    bl_label = "Move Area Label"
    bl_description = "Place this Area label and leader without changing its source faces"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.view_layer.objects.active
        return bool(context.mode == "OBJECT" and is_dimension_object(obj) and obj.dimension_props.annotation_kind == "AREA")

    def invoke(self, context, _event):
        self.annotation_name = context.view_layer.objects.active.name
        self.hover_snap = None
        self._update_preview(context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        annotation = bpy.data.objects.get(self.annotation_name)
        if annotation is None or not has_view3d_window_region(context):
            clear_preview_state()
            return {"CANCELLED"}
        result = evaluate_area_binding(annotation.dimension_props)
        if result is None:
            self.report({"ERROR"}, "Repair the Area source before moving its label")
            clear_preview_state()
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            self.hover_snap = find_nearest_snap_point(
                context,
                event.mouse_region_x,
                event.mouse_region_y,
                include_free=True,
                plane_point=result["center"],
                plane_normal=result["normal"],
            )
            self._update_preview(context)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS" and self.hover_snap is not None:
            set_object_anchor(annotation.dimension_props.end, annotation.dimension_props.area_source_object, self.hover_snap["world_co"])
            annotation.location = self.hover_snap["world_co"]
            clear_preview_state()
            return {"FINISHED"}
        if event.type in {"RIGHTMOUSE", "ESC"} and event.value == "PRESS":
            clear_preview_state()
            return {"CANCELLED"}
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            return {"PASS_THROUGH"}
        return {"RUNNING_MODAL"}

    def _update_preview(self, context):
        annotation = bpy.data.objects.get(self.annotation_name)
        if annotation is None:
            return
        props = annotation.dimension_props
        result = evaluate_area_binding(props)
        if result is None:
            return
        end = self.hover_snap["world_co"] if self.hover_snap is not None else resolve_anchor(props.end)
        set_preview_state({
            "state": "MOVE_AREA_LABEL",
            "annotation_kind": "AREA",
            "start_world": result["center"],
            "end_world": end,
            "area_value": result["area"],
            "face_count": result["face_count"],
            "hover_screen": None if self.hover_snap is None else self.hover_snap["screen_co"],
        })
