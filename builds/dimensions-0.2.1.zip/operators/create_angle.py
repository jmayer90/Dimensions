import bpy

from ..anchors import set_anchor_from_snap
from ..collections import create_dimension_object
from ..drawing import clear_preview_state, set_preview_state
from ..snapping import copy_snap, find_nearest_snap_point, has_view3d_window_region
from ..properties import is_dimension_object


class DIMENSIONS_OT_CreateAngle(bpy.types.Operator):
    bl_idname = "dimensions.create_angle"
    bl_label = "Create Angle Dimension"
    bl_description = "Pick an angle vertex, first ray, second ray, and arc radius"
    bl_options = {"REGISTER", "UNDO"}

    replace_active: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def invoke(self, context, _event):
        if not has_view3d_window_region(context):
            self.report({"ERROR"}, "Run this operator from a 3D View")
            return {"CANCELLED"}
        if context.mode not in {"OBJECT", "EDIT_MESH"}:
            self.report({"ERROR"}, "Angle dimensions work in Object Mode or Mesh Edit Mode")
            return {"CANCELLED"}
        self.target_name = ""
        if self.replace_active:
            active = context.view_layer.objects.active
            if not is_dimension_object(active) or active.dimension_props.annotation_kind != "ANGLE":
                self.report({"ERROR"}, "Select an Angle dimension to remake")
                return {"CANCELLED"}
            self.target_name = active.name
        self.state = "PICK_CENTER"
        self.center_snap = None
        self.start_snap = None
        self.end_snap = None
        self.hover_snap = None
        self.radius = 0.25
        self._update_preview()
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not has_view3d_window_region(context):
            clear_preview_state()
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            self.hover_snap = find_nearest_snap_point(
                context,
                event.mouse_region_x,
                event.mouse_region_y,
                include_free=True,
            )
            if self.state == "PICK_RADIUS" and self.hover_snap is not None:
                center = self.center_snap["world_co"]
                self.radius = max(0.001, (self.hover_snap["world_co"] - center).length)
            self._update_preview()
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            return self._accept(context, event)
        if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS" and self.state == "PICK_RADIUS":
            return self._commit(context)
        if event.type == "ESC" and event.value == "PRESS":
            if self.state == "PICK_RADIUS":
                self.state = "PICK_END"
                self.end_snap = None
            elif self.state == "PICK_END":
                self.state = "PICK_START"
                self.start_snap = None
            elif self.state == "PICK_START":
                self.state = "PICK_CENTER"
                self.center_snap = None
            else:
                clear_preview_state()
                return {"CANCELLED"}
            self._update_preview()
            return {"RUNNING_MODAL"}
        if event.type == "RIGHTMOUSE" and event.value == "PRESS":
            clear_preview_state()
            return {"CANCELLED"}
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            return {"PASS_THROUGH"}
        return {"RUNNING_MODAL"}

    def _accept(self, context, event):
        if self.hover_snap is None:
            self.hover_snap = find_nearest_snap_point(
                context,
                event.mouse_region_x,
                event.mouse_region_y,
                include_free=True,
            )
        if self.hover_snap is None:
            return {"RUNNING_MODAL"}
        if self.state == "PICK_CENTER":
            self.center_snap = copy_snap(self.hover_snap)
            self.state = "PICK_START"
        elif self.state == "PICK_START":
            if (self.hover_snap["world_co"] - self.center_snap["world_co"]).length < 1e-6:
                self.report({"WARNING"}, "First ray point must differ from the angle vertex")
                return {"RUNNING_MODAL"}
            self.start_snap = copy_snap(self.hover_snap)
            self.state = "PICK_END"
        elif self.state == "PICK_END":
            center = self.center_snap["world_co"]
            first = self.start_snap["world_co"] - center
            second = self.hover_snap["world_co"] - center
            if second.length < 1e-6 or first.normalized().dot(second.normalized()) > 0.999999:
                self.report({"WARNING"}, "Second ray must define a measurable angle")
                return {"RUNNING_MODAL"}
            self.end_snap = copy_snap(self.hover_snap)
            self.radius = max(0.001, min(first.length, second.length) * 0.35)
            self.state = "PICK_RADIUS"
        else:
            return self._commit(context)
        self._update_preview()
        return {"RUNNING_MODAL"}

    def _commit(self, context):
        if not all((self.center_snap, self.start_snap, self.end_snap)):
            return {"RUNNING_MODAL"}
        annotation = bpy.data.objects.get(self.target_name) if self.target_name else None
        if annotation is None:
            annotation = create_dimension_object(context, "ANGLE Three Point")
        props = annotation.dimension_props
        props.annotation_kind = "ANGLE"
        props.measurement_state = "LIVE"
        props.angle_radius = self.radius
        set_anchor_from_snap(props.start, self.start_snap)
        set_anchor_from_snap(props.center, self.center_snap)
        set_anchor_from_snap(props.end, self.end_snap)
        annotation.location = self.center_snap["world_co"]
        clear_preview_state()
        if context.mode == "OBJECT":
            for selected in context.selected_objects:
                selected.select_set(False)
            context.view_layer.objects.active = annotation
            annotation.select_set(True)
        self.report({"INFO"}, f"{'Remade' if self.target_name else 'Created'} three-point angle dimension")
        return {"FINISHED"}

    def _update_preview(self):
        preview = {
            "state": self.state,
            "annotation_kind": "ANGLE",
            "angle_radius": self.radius,
            "angle_mode": "MINOR",
        }
        if self.hover_snap is not None:
            preview["hover_screen"] = self.hover_snap["screen_co"]
            preview["hover_type"] = self.hover_snap.get("type", "WORLD")
            preview["hover_label"] = self.hover_snap.get("label", "Point")
            preview["hover_snap"] = copy_snap(self.hover_snap)
        if self.center_snap is not None:
            preview["center_world"] = self.center_snap["world_co"]
        if self.start_snap is not None:
            preview["start_world"] = self.start_snap["world_co"]
        elif self.state == "PICK_START" and self.hover_snap is not None:
            preview["start_world"] = self.hover_snap["world_co"]
        if self.end_snap is not None:
            preview["end_world"] = self.end_snap["world_co"]
        elif self.state == "PICK_END" and self.hover_snap is not None:
            preview["end_world"] = self.hover_snap["world_co"]
        set_preview_state(preview)
