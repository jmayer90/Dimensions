# Dimensions

A Blender extension for precise viewport dimensions, measurements, and construction guides — without creating or cutting mesh geometry.

Dimensions gives you persistent, editable annotations that stay attached to your model as it changes. It's aimed at people who need to communicate sizes and angles from a Blender scene: product and furniture design, architectural massing, fabrication drawings, and anyone who has wished Blender's measure tool remembered anything.

**Status:** early and actively developed (`0.4.x`). The interaction model is settled; the property schema is not yet frozen, but scenes now carry a schema version and are migrated on load, so annotations saved with an older version are upgraded rather than recreated. Requires **Blender 5.1 or newer**.

## Features

- **Linear dimensions** between vertices, surface points, guides, measurements, or free world points, in Object or Mesh Edit Mode.
- **Angle dimensions** from any two non-parallel edges — connected, intersecting only when extended, or skew in 3D — with minor, supplement, and reflex solutions.
- **Area dimensions** with a live face-set binding and an explicit label placement you control.
- **Measurements and construction guides** — saved finite measurements and infinite guides that other tools can snap to.
- **Snapping** to vertices, edges, midpoints, face centers, face points, guides, and measurement endpoints, midpoints, and segments.
- **Drafting inference** for parallel, perpendicular, extension, intersection, active-face planes, and rotated-object local axes, with a lockable reference and per-type preferences.
- **Typed input** in scene units — `125mm`, `2ft`, `5"` — with `A`, `X`, `Y`, and `Z` axis constraints.
- **Continuous placement** for dimensions, angles, areas, measurements, and guides, with a session axis that persists while the tool remains active.
- **Presentation control** — reusable named styles, metric and imperial formatting, projected distances, architectural tick or arrow endpoints, Inline/Above/Outside Start/Outside End text placement, value prefixes and suffixes, linear tolerances, and per-annotation overrides.
- **Renderable linear, angle, and area dimensions** generated as Grease Pencil strokes for EEVEE or Cycles, using camera-relative pixels or explicit world-space sizing.
- **Scale-correct SVG and PDF drawings** framed by an orthographic camera, with A4, A3, or US Letter paper, portrait/landscape orientation, and explicit 1:N scale.
- **A viewport HUD** showing selected-mesh dimensions and evaluated volume.

Annotations are ordinary Blender objects in dedicated `Dimensions` and `Construction Guides` collections, so they select, undo, save, and link like anything else in your scene.

## Install

Download the latest `dimensions-<version>.zip` from the [Releases](../../releases) page. In Blender, choose **Edit ▸ Preferences ▸ Add-ons ▸ Install from Disk**, select the ZIP, and enable **Dimensions**.

Installing does not change Blender's global snapping, keymaps, or Auto Merge settings.

To build the archive yourself instead, see [CONTRIBUTING.md](CONTRIBUTING.md). Windows uses PowerShell; Linux and macOS can use the included POSIX build and validation scripts.

## Getting started

Open the 3D Viewport sidebar with `N` and choose the **Dimensions** tab.

Choose a creation tool first, then use the compact, full-width **Direction** selector beneath the tool buttons to select Auto, X, Y, or Z before placing points. The **Snap Targets** row independently enables vertices, edges, midpoints, face centers, face points, guides, and measurement endpoints, midpoints, and segments. By default it edits your persistent add-on preferences; enable **Scene Override** to store a document-specific set in the `.blend` file. Continuous placement is on by default.

To select an existing annotation directly in the viewport, activate **Dimensions Selection** from the 3D View toolbar in Object Mode. Clicks that do not hit a Dimensions object continue to Blender's normal selection tool.

The **Annotation Manager** lists every dimension, measurement, and guide with its current value and Live, Fallback, Captured, or Needs Repair state. Search by name; combine kind and state filters; or capture the active mesh with **References Active** to find dependent annotations. Clicking a row name selects it. Row actions rename, show or hide, frame, delete, and open guided repair. Bulk actions operate on either the filtered rows or Blender's current selection and can show, hide, isolate, delete, assign the active named style, or reset to global style. **Exit Isolate** restores the exact visibility state from before isolation.

**A linear dimension:**

1. Click **Create Dimension** in Object or Mesh Edit Mode.
2. Click a highlighted start point, then move toward the next point.
3. Optionally press `A`, `X`, `Y`, or `Z` — press the same axis twice for the active object's local axis — or drag middle mouse after the first point.
4. Optionally type a distance and press `Enter`. Clicking also commits a valid stage.

After a commit, the tool starts another placement while retaining its session axis and placement offset. A small lower-corner badge shows the active tool and direction, plus typed distance only while you are entering one. Press `A`, `X`, `Y`, or `Z` at the fresh stage to change direction for the next annotation. Press `Esc` or right-click to exit the session. Changing mode or the active object also ends it cleanly.

In Mesh Edit Mode, **Create Dimension** is selection-first: with exactly one edge selected it commits a length immediately, and any other selection falls through to interactive picking. The contextual, collapsible **From Mesh Selection** panel also provides explicit selected-edge angle and length actions plus selected-face area actions.

**An area dimension** works in both modes. In Edit Mode, select faces first, run the tool, then place the label. In Object Mode, click a face — Shift-click to add more, `Enter` to proceed — then place the label. A selected area also exposes **Remake Area**, **Select Source Faces**, and **Capture**.

**An angle dimension** acquires Edge A, then Edge B, then the arc radius. Connected edges use their shared vertex; disconnected or skew edges derive a virtual center from their supporting lines. A selected angle can switch solution or replace either edge independently.

When topology removes or duplicates an anchor identity, its value continues to use the same stored-position fallback but is labeled **Fallback — Confirm Source** instead of looking Live. Click its manager repair icon to select available sources and show the last known position in red plus the suggested nearest vertex or face in green. The **Guided Repair** panel explains the source, frames the old position, and lets you explicitly accept the suggestion, pick a replacement through normal acquisition, convert a permanently lost anchor to a world point, or repair annotations with the same cause. Linear, angle, and area repair preserves presentation offsets and is one undoable action; linked annotations remain read-only.

**Renderable output:** open **Output** in the Dimensions sidebar, choose Selected or Visible annotations, then use the **Grease Pencil** section and choose Camera Relative or World Scale sizing. Camera Relative uses the active camera and resolves pixel sizes at each annotation's depth; World Scale uses explicit scene-unit sizes. Click **Generate Grease Pencil Output** to create renderable linear, angle, and valid Live or Captured area strokes in the scene-owned `Dimensions Output` collection. Generated objects use 3D Location depth ordering with Grease Pencil lighting disabled, and generation enables the active view layer's Depth and Grease Pencil data passes. Areas in Needs Repair are skipped until their sources are repaired. Labels and presentation offsets follow the live annotations. Live annotations remain the source of truth. Generated objects are disposable: regenerating the same annotation replaces its prior output and any hand edits to that generated object.

**Scale-correct vector export:** set an active orthographic camera and frame the model region to export. In **Output**, choose Selected or Visible scope, A4/A3/US Letter paper, portrait or landscape, and a scale denominator. A value of `10` means 1:10: 100 mm in the model measures 10 mm in the exported SVG or PDF. Set physical line weight, text height, and endpoint size in millimetres, then click **Export SVG** or **Export PDF**. The camera frame is centered on the page at the requested scale; if it cannot fit, Dimensions asks for a larger page, a larger denominator, or a tighter camera frame instead of silently changing scale. Live and Captured annotations export with their resolved colors and presentation; Fallback and Needs Repair annotations are skipped.

### Keys

| Key | Action |
| --- | --- |
| `A` `X` `Y` `Z` | Constrain to aligned or global axis |
| Middle drag | Choose a projected global axis (after the first point) |
| `S` | Cycle all snap targets, then each target individually |
| `L` | Lock or release the current inference reference |
| Type + `Enter` | Commit a scene-unit distance |
| `Esc` | Exit continuous placement; otherwise clear typed input, step back, or exit |
| Right-click | Exit the active placement session |

Every key in this table is rebindable, and the modal keys take effect as soon as you change them — no restart. The lower-corner badge shows the active snap set; **Snap: Free** means all targets are disabled and free world-point placement remains available. Creation shortcuts ship unbound, as disabled entries in the Dimensions add-on Keymap preferences, so nothing Dimensions installs can shadow a binding you already use.

During Dimension, Measure, and Guide point placement, hovering an eligible edge, guide, or face records the most recent inference reference. Parallel, perpendicular, extension, intersection, local-axis, and active-plane candidates use distinct orange glyphs and a named badge; an accepted inferred point uses the existing blue locked color. Press `L` to freeze the current reference through mouse movement, then `L` again to release it. Existing geometry wins when it is within 2 px of a derived candidate; otherwise the closer candidate wins. Preferences can disable each inference type. Edge-derived inference follows the Edge snap control, guide-derived inference follows Guide, and face-plane inference follows Face Center/Face Point.

### Placement

Linear and area annotations are placement objects. Move one with Blender's normal transform tools and you move its presentation — the source anchors stay attached, and the offset you set survives later changes to the source geometry or object transform.

Text Size and Arrow Size are fixed viewport-pixel sizes. View zoom, projection, source transforms, and the annotation Empty's scale do not enlarge the live overlay. Generated output has separate camera-pixel and world-space sizing controls.

Text Placement under **Global Dimension Settings** supports Inline, Above Line, Outside Start, and Outside End. Outside Start and Outside End place the full value/custom-text block beyond the corresponding arrow in both the live overlay and generated output.

Linear dimensions can use the default open arrows or **Architectural Tick** endpoints. Set the default under **Global Dimension Style**, or override it for the selected dimension under **Local Style**.

Named styles live in the scene under **Named Annotation Styles**. Create or duplicate a style, edit its color, selected color, line width, text size, precision, arrow presentation, unit format, prefix, suffix, and tolerance, then select annotations and click **Assign Style to Selection**. Assignment clears their local overrides so later style edits update them together. A selected annotation shows an override switch and the effective inherited value beside every style property: off means inherited; on means local. Resolution is independent for every property: local override → assigned named style → scene default. **Clear Overrides and Inherit** restores full inheritance. Deleting a style safely sends its users back to scene defaults. Rename and delete remain disabled when linked annotations use the style, because linked data cannot be rewritten safely.

## Known limitations

- Grease Pencil generation supports linear, angle, and valid Live or Captured area annotations. Measurements and construction guides remain viewport/construction data.
- Camera-relative output resolves presentation size at each dimension's midpoint. Coplanar dimensions target one output pixel of the live camera layout; dimensions that span substantially different camera depths can vary under perspective.
- Generated output is an explicit snapshot, not a live link. Regeneration replaces matching generated objects and their hand edits. The compact stroke font maps lowercase custom text to uppercase and shows a visible fallback glyph for unsupported characters.
- Generated output inherits style color, endpoint variant, precision, units, prefix, suffix, and tolerance. Its physical line, label, and endpoint sizes continue to use the separate Camera Relative or World Scale output controls, so sheets remain consistently scaled regardless of viewport pixel sizes.
- Construction guides are Object Mode only. Dimensions and measurements work in both modes.
- Vertex anchors use persistent mesh point IDs. Removed or duplicated IDs retain the prior numeric fallback but are visibly marked **Fallback** and offer explicit guided rebind; surface anchors follow object transforms but not later deformation.
- Deleting an object used by a linear, angle, or area annotation preserves the stored fallback geometry and marks the annotation **Needs Repair** instead of presenting a stale value as live. Guided repair can pick a replacement or convert a lost point source to a fixed world point. Linked and library-override annotations are shown read-only and are never rewritten by synchronization, drawing, or repair.
- Live areas bind base-mesh faces from a single object. Modifier-evaluated and multi-object areas are not supported; lost or ambiguous faces surface a visible **Needs Repair** state rather than guessing.
- Projected snapping retains exact source coordinates and scales with visible vertex count. The measured cold-cache build is 7.908 ms at 100,000 vertices and 75.252 ms at 1 million; steady queries remain effectively instant. See [`docs/DESIGN.md`](docs/DESIGN.md#measured-performance) for the full measurements.
- Overlay drawing is measured at 500 visible dimensions and holds above 30 fps; draw cost does not depend on how many other objects the scene contains.
- Persistent guide planes are not implemented. Inference is intentionally transient: it acquires a world point but does not create geometry or a maintained parametric relationship.
- Named styles are stored in each scene; there is no cross-file style library.
- SVG/PDF export is a single camera-framed page and requires an orthographic camera for one truthful scale across the drawing. Labels are portable vector strokes rather than selectable text. Title blocks, borders, DXF, and multi-sheet output are not included.

## Contributing

Issues and pull requests are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md) for how to build, test, and what the project is and isn't trying to be.

- [docs/DESIGN.md](docs/DESIGN.md) — architecture, design invariants, known risks, and the prioritized roadmap. Read this first for anything non-trivial.
- [docs/tickets/](docs/tickets/) — the canonical milestone/status dashboard plus structured work tickets with acceptance criteria and code maps.
- [docs/VERSIONING.md](docs/VERSIONING.md) — what moves the version number, and what 1.0 will mean.

## License

GPL-3.0-or-later. See [LICENSE](LICENSE).
