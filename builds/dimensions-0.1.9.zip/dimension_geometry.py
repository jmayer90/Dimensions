"""Pure world-space geometry calculations for linear dimensions."""

from mathutils import Quaternion, Vector


_AXIS_CANDIDATES = (
    Vector((1.0, 0.0, 0.0)),
    Vector((0.0, 1.0, 0.0)),
    Vector((0.0, 0.0, 1.0)),
)


def get_measure_world_points(_extension_axis, start_world, end_world):
    return start_world, end_world, (end_world - start_world).length


def get_dimension_world_geometry(
    dimension_type,
    start_world,
    end_world,
    plane_normal,
    offset_distance,
    offset_angle=0.0,
):
    measure_start_world, measure_end_world, value = get_measure_world_points(
        dimension_type,
        start_world,
        end_world,
    )
    measure_vector = measure_end_world - measure_start_world
    if measure_vector.length < 1e-6:
        return None

    measure_direction = measure_vector.normalized()
    stable_plane_normal, offset_direction = get_offset_basis(
        dimension_type,
        measure_direction,
        plane_normal,
    )
    if abs(offset_angle) >= 1e-6:
        offset_rotation = Quaternion(measure_direction, offset_angle)
        offset_direction = offset_rotation @ offset_direction
        stable_plane_normal = measure_direction.cross(offset_direction).normalized()
    if offset_direction.length < 1e-6:
        return None

    offset_direction.normalize()
    offset_vector = offset_direction * offset_distance
    line_start_world = measure_start_world + offset_vector
    line_end_world = measure_end_world + offset_vector
    return {
        "measure_start_world": measure_start_world,
        "measure_end_world": measure_end_world,
        "measure_direction_world": measure_direction,
        "plane_normal_world": stable_plane_normal,
        "offset_direction_world": offset_direction,
        "offset_distance": offset_distance,
        "offset_angle": offset_angle,
        "line_start_world": line_start_world,
        "line_end_world": line_end_world,
        "line_mid_world": (line_start_world + line_end_world) * 0.5,
        "value": value,
    }


def get_offset_basis(extension_axis, measure_direction, plane_normal):
    stable_plane_normal = sanitize_plane_normal(measure_direction, plane_normal)
    preferred_offset_direction = stable_plane_normal.cross(measure_direction)
    axis_directions = {
        "X": Vector((1.0, 0.0, 0.0)),
        "Y": Vector((0.0, 1.0, 0.0)),
        "Z": Vector((0.0, 0.0, 1.0)),
    }
    candidates = []
    for axis_name, axis_direction in axis_directions.items():
        perpendicular_axis = axis_direction - measure_direction * axis_direction.dot(measure_direction)
        if perpendicular_axis.length >= 1e-6:
            candidates.append((axis_name, perpendicular_axis.normalized()))
    if not candidates:
        return stable_plane_normal, preferred_offset_direction

    matching_candidate = None
    if extension_axis in axis_directions:
        matching_candidate = next(
            (candidate for name, candidate in candidates if name == extension_axis),
            None,
        )
    if matching_candidate is None:
        preferred_direction = preferred_offset_direction.normalized()
        _axis_name, matching_candidate = max(
            candidates,
            key=lambda item: abs(item[1].dot(preferred_direction)),
        )
        if matching_candidate.dot(preferred_direction) < 0.0:
            matching_candidate.negate()

    offset_direction = matching_candidate
    stable_plane_normal = measure_direction.cross(offset_direction).normalized()
    return stable_plane_normal, offset_direction


def sanitize_plane_normal(measure_direction, plane_normal):
    candidate = plane_normal.normalized() if plane_normal.length > 1e-6 else Vector((0.0, 0.0, 1.0))
    if abs(candidate.dot(measure_direction)) < 0.98:
        return candidate
    fallback = min(_AXIS_CANDIDATES, key=lambda axis: abs(axis.dot(measure_direction)))
    return fallback.normalized()
