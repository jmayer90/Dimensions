import bmesh
import bpy
from mathutils import Vector

from ..anchors import set_anchor, set_object_anchor
from ..collections import create_dimension_object
from ..constants import DEFAULT_OFFSET_DISTANCE
from ..dimension_geometry import get_dimension_world_geometry


def _selected_bmesh(context):
    obj = context.edit_object
    if obj is None or obj.type != "MESH":
        return None, None
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    return obj, bm


def _view_direction(context):
    if context.region_data is None:
        return Vector((0.0, 0.0, 1.0))
    return (context.region_data.view_rotation @ Vector((0.0, 0.0, -1.0))).normalized()


def create_dimension_from_selected_edge(context):
    obj, bm = _selected_bmesh(context)
    if bm is None:
        return None
    selected = [edge for edge in bm.edges if edge.select and not edge.hide]
    if len(selected) != 1:
        return None
    edge = selected[0]
    dimension = create_dimension_object(context, "DIM Selected Edge")
    props = dimension.dimension_props
    props.annotation_kind = "LINEAR"
    set_anchor(props.start, obj, edge.verts[0].index)
    set_anchor(props.end, obj, edge.verts[1].index)
    start_world = obj.matrix_world @ edge.verts[0].co
    end_world = obj.matrix_world @ edge.verts[1].co
    props.offset_plane_normal = tuple(_view_direction(context))
    props.offset_distance = DEFAULT_OFFSET_DISTANCE
    geometry = get_dimension_world_geometry(
        "ALIGNED",
        start_world,
        end_world,
        Vector(props.offset_plane_normal),
        props.offset_distance,
    )
    dimension.location = geometry["line_mid_world"] if geometry else (start_world + end_world) * 0.5
    return dimension


class DIMENSIONS_OT_DimensionSelectedEdge(bpy.types.Operator):
    bl_idname = "dimensions.dimension_selected_edge"
    bl_label = "Dimension Selected Edge"
    bl_description = "Create a linear dimension from the single selected mesh edge"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "EDIT_MESH" and context.edit_object is not None

    def execute(self, context):
        dimension = create_dimension_from_selected_edge(context)
        if dimension is None:
            self.report({"ERROR"}, "Select exactly one edge")
            return {"CANCELLED"}
        self.report({"INFO"}, "Created dimension from selected edge")
        return {"FINISHED"}


class DIMENSIONS_OT_AreaSelectedFaces(bpy.types.Operator):
    bl_idname = "dimensions.area_selected_faces"
    bl_label = "Annotate Selected Face Area"
    bl_description = "Create a leader annotation for the combined area of selected faces"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "EDIT_MESH" and context.edit_object is not None

    def execute(self, context):
        obj, bm = _selected_bmesh(context)
        faces = [face for face in bm.faces if face.select and not face.hide]
        if not faces:
            self.report({"ERROR"}, "Select one or more faces")
            return {"CANCELLED"}

        linear = obj.matrix_world.to_3x3()
        normal_matrix = linear.inverted_safe().transposed()
        determinant = abs(linear.determinant())
        total_area = 0.0
        weighted_center = Vector((0.0, 0.0, 0.0))
        weighted_normal = Vector((0.0, 0.0, 0.0))
        for face in faces:
            world_normal = normal_matrix @ face.normal
            area = face.calc_area() * determinant * world_normal.length
            if area <= 1e-12:
                continue
            world_normal.normalize()
            center = obj.matrix_world @ face.calc_center_median_weighted()
            total_area += area
            weighted_center += center * area
            weighted_normal += world_normal * area
        if total_area <= 1e-12:
            self.report({"ERROR"}, "Selected faces have no measurable area")
            return {"CANCELLED"}

        center = weighted_center / total_area
        normal = weighted_normal.normalized() if weighted_normal.length > 1e-8 else Vector((0.0, 0.0, 1.0))
        axes = (Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1)))
        tangent = max(
            (axis - normal * axis.dot(normal) for axis in axes),
            key=lambda value: value.length_squared,
        ).normalized()
        leader_length = max(DEFAULT_OFFSET_DISTANCE * 2.0, total_area ** 0.5 * 0.25)
        label_point = center + tangent * leader_length

        annotation = create_dimension_object(context, "AREA Selected Faces")
        props = annotation.dimension_props
        props.annotation_kind = "AREA"
        props.area_value = total_area
        set_object_anchor(props.start, obj, center)
        set_object_anchor(props.end, obj, label_point)
        annotation.location = label_point
        self.report({"INFO"}, f"Created area annotation from {len(faces)} face(s)")
        return {"FINISHED"}


class DIMENSIONS_OT_AngleSelectedEdges(bpy.types.Operator):
    bl_idname = "dimensions.angle_selected_edges"
    bl_label = "Dimension Selected Angle"
    bl_description = "Create an angle dimension from two selected connected edges"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "EDIT_MESH" and context.edit_object is not None

    def execute(self, context):
        obj, bm = _selected_bmesh(context)
        edges = [edge for edge in bm.edges if edge.select and not edge.hide]
        if len(edges) != 2:
            self.report({"ERROR"}, "Select exactly two connected edges")
            return {"CANCELLED"}
        shared = set(edges[0].verts).intersection(edges[1].verts)
        if len(shared) != 1:
            self.report({"ERROR"}, "Selected edges must share one vertex")
            return {"CANCELLED"}
        center = shared.pop()
        outer = [next(vertex for vertex in edge.verts if vertex != center) for edge in edges]
        annotation = create_dimension_object(context, "ANGLE Selected Edges")
        props = annotation.dimension_props
        props.annotation_kind = "ANGLE"
        set_anchor(props.start, obj, outer[0].index)
        set_anchor(props.center, obj, center.index)
        set_anchor(props.end, obj, outer[1].index)
        annotation.location = obj.matrix_world @ center.co
        self.report({"INFO"}, "Created angle dimension from selected edges")
        return {"FINISHED"}


classes = (
    DIMENSIONS_OT_DimensionSelectedEdge,
    DIMENSIONS_OT_AreaSelectedFaces,
    DIMENSIONS_OT_AngleSelectedEdges,
)
