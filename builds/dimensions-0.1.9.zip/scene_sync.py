"""Scene data synchronization and dependency-graph cache invalidation."""

import bpy
from bpy.app.handlers import persistent
from mathutils import Vector

from .anchors import migrate_anchor_identity, resolve_anchor
from .collections import ensure_measurement_snap_proxy, remove_orphan_measurement_snap_proxies
from .dimension_geometry import get_dimension_world_geometry
from .projected_snap import invalidate_projected_snap_cache_from_depsgraph
from .properties import is_dimension_object, is_guide_object
from .volume import clear_volume_cache, invalidate_volume_cache_from_depsgraph


_sync_active = False
_sync_scheduled = False


def register_scene_sync():
    if _depsgraph_sync_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_depsgraph_sync_handler)
    schedule_scene_sync()


def unregister_scene_sync():
    global _sync_scheduled
    if _depsgraph_sync_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_sync_handler)
    if bpy.app.timers.is_registered(_run_scheduled_sync):
        bpy.app.timers.unregister(_run_scheduled_sync)
    _sync_scheduled = False
    clear_volume_cache()
    invalidate_projected_snap_cache_from_depsgraph(None)


def schedule_scene_sync():
    global _sync_scheduled
    if _sync_scheduled:
        return
    _sync_scheduled = True
    bpy.app.timers.register(_run_scheduled_sync, first_interval=0.0)


def _run_scheduled_sync():
    global _sync_scheduled
    _sync_scheduled = False
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        sync_scene_objects(scene)
    return None


@persistent
def _depsgraph_sync_handler(scene, depsgraph):
    invalidate_volume_cache_from_depsgraph(depsgraph)
    invalidate_projected_snap_cache_from_depsgraph(depsgraph)
    sync_scene_objects(scene)


def sync_scene_objects(scene):
    global _sync_active
    if _sync_active or scene is None:
        return
    _sync_active = True
    try:
        remove_orphan_measurement_snap_proxies(scene)
        for obj in list(scene.objects):
            if is_guide_object(obj):
                _sync_guide(obj, scene)
            elif is_dimension_object(obj):
                _sync_dimension(obj)
    finally:
        _sync_active = False


def _sync_guide(obj, scene):
    migrate_anchor_identity(obj.guide_props.start)
    migrate_anchor_identity(obj.guide_props.end)
    start_world = resolve_anchor(obj.guide_props.start)
    target_world = start_world
    if getattr(obj.guide_props, "kind", "GUIDE") == "MEASUREMENT":
        end_world = resolve_anchor(obj.guide_props.end)
        if start_world is not None and end_world is not None:
            target_world = (start_world + end_world) * 0.5
    _set_translation(obj, target_world)
    if getattr(obj.guide_props, "kind", "GUIDE") == "MEASUREMENT":
        ensure_measurement_snap_proxy(obj, scene)


def _sync_dimension(obj):
    props = obj.dimension_props
    migrate_anchor_identity(props.start)
    migrate_anchor_identity(props.end)
    start_world = resolve_anchor(props.start)
    end_world = resolve_anchor(props.end)
    if start_world is None or end_world is None:
        return
    annotation_kind = getattr(props, "annotation_kind", "LINEAR")
    if annotation_kind == "AREA":
        _set_translation(obj, end_world)
        return
    if annotation_kind == "ANGLE":
        migrate_anchor_identity(props.center)
        center_world = resolve_anchor(props.center)
        _set_translation(obj, center_world)
        return
    geometry = get_dimension_world_geometry(
        props.dimension_type,
        start_world,
        end_world,
        Vector(props.offset_plane_normal),
        props.offset_distance,
        props.offset_angle,
    )
    if geometry is not None:
        _set_translation(obj, geometry["line_mid_world"])


def _set_translation(obj, target_world):
    if target_world is None or (obj.matrix_world.translation - target_world).length <= 1e-6:
        return
    matrix_world = obj.matrix_world.copy()
    matrix_world.translation = target_world
    obj.matrix_world = matrix_world
