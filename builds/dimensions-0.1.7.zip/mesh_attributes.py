"""Preserve BMesh custom data during topology reconstruction."""

from .anchors import VERTEX_ID_ATTRIBUTE


_FACE_LAYER_TYPES = (
    "bool",
    "color",
    "float",
    "float_color",
    "float_vector",
    "int",
    "string",
)


def copy_face_and_loop_attributes(bm, source_face, face):
    """Copy face data and interpolate loop/vertex data before source removal."""
    for layer_type in _FACE_LAYER_TYPES:
        layers = getattr(bm.faces.layers, layer_type)
        for name in layers.keys():
            layer = layers.get(name)
            face[layer] = source_face[layer]
    face.material_index = source_face.material_index
    face.smooth = source_face.smooth
    anchor_id_layer = bm.verts.layers.int.get(VERTEX_ID_ATTRIBUTE)
    for loop in face.loops:
        anchor_id = loop.vert[anchor_id_layer] if anchor_id_layer is not None else None
        loop.copy_from_face_interp(source_face, True, True)
        if anchor_id_layer is not None:
            loop.vert[anchor_id_layer] = anchor_id
