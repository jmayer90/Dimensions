"""Explicit, user-confirmed repair inspection and rebinding helpers."""

from mathutils import Vector

from .anchors import (
    anchor_resolution,
    dimension_source_anchors,
    refresh_dimension_anchor_resolutions,
    resolve_anchor,
    set_anchor,
    set_object_anchor,
)
from .area_binding import area_source_is_read_only, bind_area_face_indices, evaluate_area_binding
from .properties import is_dimension_object


def _refresh_repaired_state(props):
    return refresh_dimension_anchor_resolutions(props)


def _repair_anchor_items(props):
    return tuple(dimension_source_anchors(props))


def repair_anchor(props, name):
    return dict(_repair_anchor_items(props)).get(name)


def repair_issues(annotation):
    if not is_dimension_object(annotation):
        return ()
    props = annotation.dimension_props
    issues = []
    for name, anchor in _repair_anchor_items(props):
        world, status = anchor_resolution(anchor)
        if status == "BY_ID":
            continue
        source_name = anchor.source_object_name or (
            anchor.target_object.name if anchor.target_object is not None else "Deleted source"
        )
        issues.append({
            "type": "ANCHOR",
            "anchor_name": name,
            "status": status,
            "source_name": source_name,
            "world_co": Vector(world),
            "candidate": suggest_vertex_candidate(anchor),
        })
    if props.annotation_kind == "AREA" and props.measurement_state != "CAPTURED" and evaluate_area_binding(props) is None:
        source = props.area_source_object
        source_name = source.name if source is not None else (props.start.source_object_name or "Deleted source")
        issues.append({
            "type": "AREA",
            "status": "UNRESOLVABLE" if source is None else "BY_FALLBACK",
            "source_name": source_name,
            "world_co": area_last_known_world(props),
            "candidate": suggest_area_candidate(props),
        })
    return tuple(issues)


def stored_repair_issues(annotation):
    """Return the issues recorded by the last scene sync, without reading mesh data.

    Sidebar polls and redraws use this. Live resolution and the candidate search
    in ``repair_issues`` scan the whole source mesh, so they run only when the user
    acts on an issue. Every returned ``candidate`` is None.
    """
    if not is_dimension_object(annotation):
        return ()
    props = annotation.dimension_props
    issues = []
    for name, anchor in _repair_anchor_items(props):
        if anchor.resolution_status == "BY_ID":
            continue
        source = anchor.target_object
        issues.append({
            "type": "ANCHOR",
            "anchor_name": name,
            "status": anchor.resolution_status,
            "source_name": anchor.source_object_name or (source.name if source is not None else "Deleted source"),
            "world_co": (
                source.matrix_world @ Vector(anchor.fallback_local_co)
                if source is not None else Vector(anchor.world_co)
            ),
            "candidate": None,
        })
    if props.annotation_kind == "AREA" and props.measurement_state == "NEEDS_REPAIR":
        source = props.area_source_object
        issues.append({
            "type": "AREA",
            "status": "UNRESOLVABLE" if source is None else "BY_FALLBACK",
            "source_name": source.name if source is not None else (props.start.source_object_name or "Deleted source"),
            "world_co": area_last_known_world(props),
            "candidate": None,
        })
    return tuple(issues)


def suggest_vertex_candidate(anchor):
    _world, status = anchor_resolution(anchor)
    obj = anchor.target_object
    if status == "BY_ID" or obj is None or obj.type != "MESH":
        return None
    fallback = Vector(anchor.fallback_local_co)
    if obj.data.is_editmode:
        import bmesh

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.index_update()
        bm.verts.ensure_lookup_table()
        if not bm.verts:
            return None
        vertex = min(bm.verts, key=lambda item: (item.co - fallback).length_squared)
        return {
            "object": obj,
            "vertex_index": vertex.index,
            "world_co": obj.matrix_world @ vertex.co,
            "label": f"{obj.name} vertex {vertex.index}",
        }
    if not obj.data.vertices:
        return None
    vertex = min(obj.data.vertices, key=lambda item: (item.co - fallback).length_squared)
    return {
        "object": obj,
        "vertex_index": vertex.index,
        "world_co": obj.matrix_world @ vertex.co,
        "label": f"{obj.name} vertex {vertex.index}",
    }


def area_last_known_world(props):
    source = props.area_source_object
    if props.area_faces:
        local = sum((Vector(item.fallback_center) for item in props.area_faces), Vector()) / len(props.area_faces)
        if source is not None:
            return source.matrix_world @ local
    return Vector(props.start.world_co)


def suggest_area_candidate(props):
    obj = props.area_source_object
    bindings = list(props.area_faces)
    if obj is None or obj.type != "MESH" or not bindings or area_source_is_read_only(obj):
        return None
    if obj.data.is_editmode:
        import bmesh

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.index_update()
        bm.faces.ensure_lookup_table()
        if not bm.faces:
            return None
        remaining = set(range(len(bm.faces)))
        chosen = []
        for binding in bindings:
            candidates = [bm.faces[index] for index in remaining]
            if not candidates:
                return None
            compatible = [face for face in candidates if len(face.verts) == binding.vertex_count]
            candidates = compatible or candidates
            center = Vector(binding.fallback_center)
            normal = Vector(binding.fallback_normal)
            area = max(binding.fallback_area, 1e-12)
            face = min(candidates, key=lambda item: (
                (item.calc_center_median() - center).length_squared
                + (1.0 - abs(item.normal.dot(normal)))
                + abs(item.calc_area() - area) / area
            ))
            chosen.append(face.index)
            remaining.discard(face.index)
        center = sum((bm.faces[index].calc_center_median() for index in chosen), Vector()) / len(chosen)
        return {
            "object": obj,
            "face_indices": tuple(chosen),
            "world_co": obj.matrix_world @ center,
            "label": f"{obj.name} face" if len(chosen) == 1 else f"{obj.name} {len(chosen)} faces",
        }
    if not obj.data.polygons:
        return None
    remaining = set(range(len(obj.data.polygons)))
    chosen = []
    for binding in bindings:
        candidates = [obj.data.polygons[index] for index in remaining]
        if not candidates:
            return None
        compatible = [face for face in candidates if len(face.vertices) == binding.vertex_count]
        candidates = compatible or candidates
        center = Vector(binding.fallback_center)
        normal = Vector(binding.fallback_normal)
        area = max(binding.fallback_area, 1e-12)
        face = min(candidates, key=lambda item: (
            (Vector(item.center) - center).length_squared
            + (1.0 - abs(Vector(item.normal).dot(normal)))
            + abs(item.area - area) / area
        ))
        chosen.append(face.index)
        remaining.discard(face.index)
    center = sum((Vector(obj.data.polygons[index].center) for index in chosen), Vector()) / len(chosen)
    return {
        "object": obj,
        "face_indices": tuple(chosen),
        "world_co": obj.matrix_world @ center,
        "label": f"{obj.name} face" if len(chosen) == 1 else f"{obj.name} {len(chosen)} faces",
    }


def apply_suggested_repairs(annotation):
    """Apply available suggestions only to currently broken/fallback sources."""
    if not is_dimension_object(annotation):
        return 0
    props = annotation.dimension_props
    issues = repair_issues(annotation)
    changed = 0
    for issue in issues:
        changed += int(apply_repair_issue(annotation, issue))
    if changed:
        props.measurement_state = _refresh_repaired_state(props)
    return changed


def apply_repair_issue(annotation, issue):
    candidate = issue.get("candidate")
    if candidate is None or not is_dimension_object(annotation):
        return False
    props = annotation.dimension_props
    if issue["type"] == "AREA":
        return rebind_area_preserving_presentation(props, candidate["object"], candidate["face_indices"])
    anchor = repair_anchor(props, issue.get("anchor_name"))
    if anchor is None or anchor_resolution(anchor)[1] == "BY_ID":
        return False
    set_anchor(anchor, candidate["object"], candidate["vertex_index"])
    props.measurement_state = _refresh_repaired_state(props)
    return True


def rebind_area_preserving_presentation(props, source, face_indices):
    if props.annotation_kind != "AREA" or props.measurement_state == "CAPTURED":
        return False
    old_label_world = resolve_anchor(props.end)
    result = bind_area_face_indices(props, source, face_indices)
    if result is None:
        return False
    props.area_value = result["area"]
    props.area_face_count = result["face_count"]
    set_object_anchor(props.start, source, result["center"])
    set_object_anchor(props.end, source, old_label_world)
    props.measurement_state = result.get("state", "LIVE")
    return True


def repair_cause(issue):
    return issue["type"], issue["status"], issue["source_name"]
